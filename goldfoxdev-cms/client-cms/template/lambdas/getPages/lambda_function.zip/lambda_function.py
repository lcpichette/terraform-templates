# Some code
def lambda_handler():
    return json.dumps({ value: "xyz" })
